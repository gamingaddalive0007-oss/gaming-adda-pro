package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.Tournament
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.MyTournamentsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SupportScreen
import com.example.ui.screens.TournamentDetailScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.GamingViewModel
import com.example.ui.screens.AuthScreen
import com.google.firebase.auth.FirebaseAuth

enum class NavigationScreen(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Default.Home),
    MY_MATCHES("My Matches", Icons.Default.EventAvailable),
    RESULTS("Results", Icons.Default.EmojiEvents),
    WALLET("Wallet", Icons.Default.MonetizationOn),
    PROFILE("Profile", Icons.Default.Person)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: GamingViewModel = viewModel()
                GamingAddaRoot(viewModel = viewModel)
            }
        }
    }
}


@Composable
fun GamingAddaRoot(viewModel: GamingViewModel) {
    val auth = remember { FirebaseAuth.getInstance() }
    var firebaseUser by remember { mutableStateOf(auth.currentUser) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener {
            firebaseUser = it.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose {
            auth.removeAuthStateListener(listener)
        }
    }

    val user = firebaseUser

    if (user == null) {
        AuthScreen(onAuthenticated = { _, _ -> })
    } else {
        LaunchedEffect(user.uid, user.email) {
            viewModel.setAuthenticatedUser(user.uid, user.email.orEmpty())
        }
        GamingApp(viewModel = viewModel)
    }
}

@Composable
fun GamingApp(viewModel: GamingViewModel) {
    var currentTab by remember { mutableStateOf(NavigationScreen.HOME) }
    var viewingTournament by remember { mutableStateOf<Tournament?>(null) }
    var viewingSupport by remember { mutableStateOf(false) }
    var viewingAdmin by remember { mutableStateOf(false) }

    val snackBarMessage by viewModel.snackBarMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackBarMessage) {
        snackBarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackBar()
        }
    }

    // Back handling for nested screens
    BackHandler(enabled = viewingTournament != null || viewingSupport || viewingAdmin || currentTab != NavigationScreen.HOME) {
        when {
            viewingTournament != null -> viewingTournament = null
            viewingSupport -> viewingSupport = false
            viewingAdmin -> viewingAdmin = false
            currentTab != NavigationScreen.HOME -> currentTab = NavigationScreen.HOME
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when {
            viewingTournament != null -> {
                TournamentDetailScreen(
                    tournament = viewingTournament!!,
                    viewModel = viewModel,
                    onBack = { viewingTournament = null },
                    onWalletClick = {
                        viewingTournament = null
                        currentTab = NavigationScreen.WALLET
                    }
                )
            }
            viewingSupport -> {
                SupportScreen(
                    viewModel = viewModel,
                    onBack = { viewingSupport = false }
                )
            }
            viewingAdmin -> {
                AdminDashboardScreen(
                    viewModel = viewModel,
                    onBack = { viewingAdmin = false }
                )
            }
            else -> {
                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = DarkSurface,
                            tonalElevation = 8.dp
                        ) {
                            NavigationScreen.values().forEach { screen ->
                                val isSelected = currentTab == screen
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = screen },
                                    icon = {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = screen.label,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = NeonCyan,
                                        selectedTextColor = NeonCyan,
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted,
                                        indicatorColor = NeonCyan.copy(alpha = 0.15f)
                                    )
                                )
                            }
                        }
                    },
                    snackbarHost = {
                        SnackbarHost(hostState = snackbarHostState)
                    },
                    containerColor = DarkBg
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            NavigationScreen.HOME -> HomeScreen(
                                viewModel = viewModel,
                                onTournamentClick = { viewingTournament = it },
                                onWalletClick = { currentTab = NavigationScreen.WALLET },
                                onAdminClick = { viewingAdmin = true }
                            )
                            NavigationScreen.MY_MATCHES -> MyTournamentsScreen(
                                viewModel = viewModel,
                                onTournamentClick = { viewingTournament = it },
                                onBrowseClick = { currentTab = NavigationScreen.HOME },
                                onWalletClick = { currentTab = NavigationScreen.WALLET }
                            )
                            NavigationScreen.RESULTS -> ResultsScreen(
                                viewModel = viewModel,
                                onWalletClick = { currentTab = NavigationScreen.WALLET }
                            )
                            NavigationScreen.WALLET -> WalletScreen(
                                viewModel = viewModel
                            )
                            NavigationScreen.PROFILE -> ProfileScreen(
                                viewModel = viewModel,
                                onSupportClick = { viewingSupport = true },
                                onAdminClick = { viewingAdmin = true },
                                onWalletClick = { currentTab = NavigationScreen.WALLET }
                            )
                        }
                    }
                }
            }
        }
    }
}
