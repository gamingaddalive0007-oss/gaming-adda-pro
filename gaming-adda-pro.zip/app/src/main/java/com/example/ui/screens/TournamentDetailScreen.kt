package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Tournament
import com.example.ui.components.GameCategoryBadge
import com.example.ui.components.NeonCoinBadge
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.LoneWolfPurple
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TdmCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.GamingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TournamentDetailScreen(
    tournament: Tournament,
    viewModel: GamingViewModel,
    onBack: () -> Unit,
    onWalletClick: () -> Unit
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val myParticipants by viewModel.myParticipants.collectAsState()

    val myParticipant = remember(myParticipants, tournament.id) {
        myParticipants.find { it.tournamentId == tournament.id }
    }
    val isRegistered = myParticipant != null

    var showJoinDialog by remember { mutableStateOf(false) }
    var selectedSlot by remember { mutableIntStateOf(1) }

    val isTdm = tournament.category.equals("TDM", ignoreCase = true)
    val isLoneWolf = tournament.category.equals("LONE_WOLF", ignoreCase = true)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isTdm) "BGMI TDM MATCH" else if (isLoneWolf) "FF LONE WOLF" else "MATCH DETAILS",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = NeonCyan
                        )
                    }
                },
                actions = {
                    NeonCoinBadge(
                        coins = currentUser?.coinBalance ?: 0,
                        onClick = onWalletClick,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = BorderStroke(
                        1.dp,
                        if (isTdm) NeonCyan else if (isLoneWolf) LoneWolfPurple else DarkBorder
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GameCategoryBadge(
                                game = tournament.game,
                                category = tournament.category,
                                mode = tournament.mode
                            )
                            StatusBadge(status = tournament.status)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = tournament.title,
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Match Time: ${tournament.matchTime}",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Map: ${tournament.map} • Mode: ${tournament.mode}",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Stats Matrix: Prize Pool, Entry Fee, Kill Points, Match Points
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCardElevated),
                    border = BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "PRIZE & POINTS STRUCTURE",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Total Prize Pool", color = TextSecondary, fontSize = 12.sp)
                                Text(
                                    text = "${tournament.prizePoolCoins} Coins",
                                    color = NeonGold,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(text = "Entry Fee", color = TextSecondary, fontSize = 12.sp)
                                Text(
                                    text = "${tournament.entryFeeCoins} Coins",
                                    color = TextPrimary,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 12.dp),
                            color = DarkBorder
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (isTdm) "TDM Per Kill Coins" else "Per Kill Coins",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "+${tournament.perKillCoins} Coins / Kill",
                                    color = NeonCyan,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(
                                    text = if (isTdm) "Match / Win Points" else "Booyah Points",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = "+${tournament.matchPoints} Points",
                                    color = NeonGreen,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Room Credentials Card (Secured: Only for registered participants)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = BorderStroke(
                        1.dp,
                        if (isRegistered) NeonGreen else DarkBorder
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isRegistered) Icons.Default.Key else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isRegistered) NeonGreen else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ROOM CREDENTIALS",
                                    color = if (isRegistered) NeonGreen else TextMuted,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (isRegistered) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = NeonGreen.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "SLOT #${myParticipant?.slotNumber}",
                                        color = NeonGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (!isRegistered) {
                            Text(
                                text = "🔒 Room ID and Password are protected and will only be visible to players who register for this match.",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        } else {
                            if (tournament.roomId.isNotBlank()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DarkSurface, RoundedCornerShape(8.dp))
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = "ROOM ID", color = TextMuted, fontSize = 10.sp)
                                        Text(
                                            text = tournament.roomId,
                                            color = NeonCyan,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = "PASSWORD", color = TextMuted, fontSize = 10.sp)
                                        Text(
                                            text = tournament.roomPassword,
                                            color = NeonGreen,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    IconButton(onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText(
                                            "Room Credentials",
                                            "Room ID: ${tournament.roomId}\nPassword: ${tournament.roomPassword}"
                                        )
                                        clipboard.setPrimaryClip(clip)
                                        viewModel.showMessage("Room ID & Password copied!")
                                    }) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy",
                                            tint = NeonCyan
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = "⏳ Room ID and Password have not been set by Admin yet. They will appear here 15 minutes before match start time.",
                                    color = NeonAmber,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // Rules & Instructions
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = BorderStroke(1.dp, DarkBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "TOURNAMENT RULES & Anti-Cheat",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = tournament.rules,
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Slots Grid Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SELECT TOURNAMENT SLOT",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${tournament.filledSlots} / ${tournament.totalSlots} Booked",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Slots display (Interactive)
            item {
                val slotsList = (1..tournament.totalSlots).toList()
                val isFull = tournament.filledSlots >= tournament.totalSlots

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkCard, RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    // Slots in rows of 5
                    for (chunk in slotsList.chunked(5)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (slotNum in chunk) {
                                val isBooked = slotNum <= tournament.filledSlots
                                val isMySlot = myParticipant?.slotNumber == slotNum
                                val isChosen = selectedSlot == slotNum && !isBooked

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(44.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when {
                                                isMySlot -> NeonGreen.copy(alpha = 0.3f)
                                                isBooked -> DarkBorder
                                                isChosen -> NeonCyan.copy(alpha = 0.3f)
                                                else -> DarkCardElevated
                                            }
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = when {
                                                isMySlot -> NeonGreen
                                                isChosen -> NeonCyan
                                                isBooked -> Color.Transparent
                                                else -> DarkBorder
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable(enabled = !isBooked && !isRegistered && tournament.status == "UPCOMING") {
                                            selectedSlot = slotNum
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "#$slotNum",
                                            color = when {
                                                isMySlot -> NeonGreen
                                                isChosen -> NeonCyan
                                                isBooked -> TextMuted
                                                else -> TextPrimary
                                            },
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = when {
                                                isMySlot -> "YOU"
                                                isBooked -> "TAKEN"
                                                else -> "OPEN"
                                            },
                                            color = when {
                                                isMySlot -> NeonGreen
                                                isBooked -> TextMuted
                                                else -> NeonCyan.copy(alpha = 0.8f)
                                            },
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Action Button
            item {
                Spacer(modifier = Modifier.height(8.dp))

                if (isRegistered) {
                    Button(
                        onClick = { viewModel.showMessage("You are already registered for Slot #${myParticipant?.slotNumber}") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, NeonGreen)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "REGISTERED (SLOT #${myParticipant?.slotNumber})",
                            color = NeonGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                } else if (tournament.status != "UPCOMING") {
                    Button(
                        onClick = {},
                        enabled = false,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(disabledContainerColor = DarkBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "REGISTRATION CLOSED (${tournament.status})",
                            color = TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (tournament.filledSlots >= tournament.totalSlots) {
                    Button(
                        onClick = {},
                        enabled = false,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(disabledContainerColor = DarkBorder),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "TOURNAMENT SLOTS FULL",
                            color = TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Button(
                        onClick = { showJoinDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isTdm) NeonCyan else if (isLoneWolf) LoneWolfPurple else NeonCyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "BOOK SLOT #$selectedSlot (${tournament.entryFeeCoins} COINS)",
                            color = DarkBg,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }

    // Join Tournament Dialog
    if (showJoinDialog) {
        val isBgmi = tournament.game == "BGMI"
        var inGameId by remember {
            mutableStateOf(if (isBgmi) currentUser?.inGameIdBgmi ?: "" else currentUser?.inGameIdFreeFire ?: "")
        }
        var inGameName by remember {
            mutableStateOf(if (isBgmi) currentUser?.inGameNameBgmi ?: "" else currentUser?.inGameNameFreeFire ?: "")
        }
        var teamMembers by remember { mutableStateOf("") }
        val isSquadOrCS = tournament.category.equals("CLASH_SQUAD", true) || tournament.mode == "Squad"
        var registrationType by remember { mutableStateOf(if (isSquadOrCS) "TEAM" else "SOLO") }
        var teamName by remember { mutableStateOf("") }
        var player2 by remember { mutableStateOf("") }
        var player3 by remember { mutableStateOf("") }
        var player4 by remember { mutableStateOf("") }
        var subPlayer by remember { mutableStateOf("") }

        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showJoinDialog = false },
            title = {
                Text(
                    text = "Confirm Slot #$selectedSlot Registration",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Tournament: ${tournament.title}",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurface,
                        border = BorderStroke(1.dp, NeonGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "Entry Fee:", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                text = "${tournament.entryFeeCoins} Virtual Coins",
                                color = NeonGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    OutlinedTextField(
                        value = inGameId,
                        onValueChange = { inGameId = it },
                        label = { Text(if (isBgmi) "BGMI Character ID (Numeric)" else "Free Fire UID (Numeric)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = inGameName,
                        onValueChange = { inGameName = it },
                        label = { Text(if (isBgmi) "BGMI IGN (In-Game Name)" else "Free Fire IGN") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    if (isSquadOrCS) {
                        Text("Registration Format", color = TextSecondary, fontSize = 11.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { registrationType = "TEAM" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (registrationType == "TEAM") NeonCyan else DarkCardElevated
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "Full Team (4+1 Sub)",
                                    color = if (registrationType == "TEAM") DarkBg else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Button(
                                onClick = { registrationType = "SOLO" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (registrationType == "SOLO") NeonCyan else DarkCardElevated
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "Solo in Squad",
                                    color = if (registrationType == "SOLO") DarkBg else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (registrationType == "TEAM") {
                            OutlinedTextField(
                                value = teamName,
                                onValueChange = { teamName = it },
                                label = { Text("Team / Squad Name") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = player2,
                                onValueChange = { player2 = it },
                                label = { Text("Player 2 (IGN / UID)") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = player3,
                                onValueChange = { player3 = it },
                                label = { Text("Player 3 (IGN / UID)") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = player4,
                                onValueChange = { player4 = it },
                                label = { Text("Player 4 (IGN / UID)") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = subPlayer,
                                onValueChange = { subPlayer = it },
                                label = { Text("Substitute Player 5 (Optional)") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                                singleLine = true
                            )
                        }
                    } else if (tournament.mode == "Duo") {
                        OutlinedTextField(
                            value = teamMembers,
                            onValueChange = { teamMembers = it },
                            label = { Text("Teammate (IGN / UID)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                            singleLine = true
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inGameId.isBlank()) {
                            viewModel.showMessage("Please enter your in-game Character ID / UID")
                            return@Button
                        }
                        if (inGameName.isBlank()) {
                            viewModel.showMessage("Please enter your in-game name")
                            return@Button
                        }
                        val finalTeamMembers = if (isSquadOrCS && registrationType == "TEAM") {
                            val list = listOfNotNull(
                                if (teamName.isNotBlank()) "Team: $teamName" else null,
                                "Leader: $inGameName",
                                if (player2.isNotBlank()) "P2: $player2" else null,
                                if (player3.isNotBlank()) "P3: $player3" else null,
                                if (player4.isNotBlank()) "P4: $player4" else null,
                                if (subPlayer.isNotBlank()) "Sub: $subPlayer" else null
                            )
                            list.joinToString(", ")
                        } else teamMembers

                        viewModel.registerForTournament(
                            tournamentId = tournament.id,
                            inGameId = inGameId,
                            inGameName = inGameName,
                            slotNumber = selectedSlot,
                            teamMembers = finalTeamMembers,
                            onSuccess = {
                                showJoinDialog = false
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Deduct ${tournament.entryFeeCoins} Coins & Join", color = DarkBg, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showJoinDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                ) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkCard
        )
    }
}
