package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.CoinTransaction
import com.example.data.model.MatchResult
import com.example.data.model.Participant
import com.example.data.model.PlayerRankItem
import com.example.data.model.SupportTicket
import com.example.data.model.Tournament
import com.example.data.model.User
import com.example.data.repository.GamingAddaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class GamingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GamingAddaRepository.getInstance(application)

    // Current Active User ID
    private val _currentUserId = MutableStateFlow("player_user_123")
    val currentUserId: StateFlow<String> = _currentUserId.asStateFlow()

    // Current User Profile
    val currentUser: StateFlow<User?> = _currentUserId.flatMapLatest { uid ->
        repository.getUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Admin state check
    val isAdmin: StateFlow<Boolean> = currentUser.map { user ->
        user != null && user.userId == GamingAddaRepository.ADMIN_UID
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // All Tournaments
    val allTournaments: StateFlow<List<Tournament>> = repository.getAllTournaments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Free Fire Tournaments
    val freeFireTournaments: StateFlow<List<Tournament>> = allTournaments.map { list ->
        list.filter { it.game.equals("Free Fire", ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Free Fire Lone Wolf Tournaments
    val loneWolfTournaments: StateFlow<List<Tournament>> = allTournaments.map { list ->
        list.filter { it.game.equals("Free Fire", ignoreCase = true) && it.category.equals("LONE_WOLF", ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Free Fire Clash Squad Tournaments
    val clashSquadTournaments: StateFlow<List<Tournament>> = allTournaments.map { list ->
        list.filter { it.game.equals("Free Fire", ignoreCase = true) && it.category.equals("CLASH_SQUAD", ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User's Registered Tournaments
    val myParticipants: StateFlow<List<Participant>> = _currentUserId.flatMapLatest { uid ->
        repository.getParticipantsForUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tournaments registered by user
    val myRegisteredTournaments: StateFlow<List<Pair<Tournament, Participant>>> = combine(
        allTournaments,
        myParticipants
    ) { tournaments, participants ->
        participants.mapNotNull { participant ->
            val tourney = tournaments.find { it.id == participant.tournamentId }
            if (tourney != null) tourney to participant else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Match Results
    val allMatchResults: StateFlow<List<MatchResult>> = repository.getAllMatchResults()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Leaderboard Users
    val leaderboardUsers: StateFlow<List<User>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Wallet Transactions
    val coinTransactions: StateFlow<List<CoinTransaction>> = _currentUserId.flatMapLatest { uid ->
        repository.getTransactionsForUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Announcements
    val announcements: StateFlow<List<Announcement>> = repository.getAllAnnouncements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Support Tickets
    val supportTickets: StateFlow<List<SupportTicket>> = _currentUserId.flatMapLatest { uid ->
        repository.getTicketsForUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Tournament for details
    private val _selectedTournament = MutableStateFlow<Tournament?>(null)
    val selectedTournament: StateFlow<Tournament?> = _selectedTournament.asStateFlow()

    // Transient Feedback Toast/Snackbar
    private val _snackBarMessage = MutableStateFlow<String?>(null)
    val snackBarMessage: StateFlow<String?> = _snackBarMessage.asStateFlow()


    fun setAuthenticatedUser(uid: String, email: String) {
        viewModelScope.launch {
            _currentUserId.value = uid

            val existingUser = repository.getUser(uid).first()

            if (existingUser == null) {
                val playerName = email.substringBefore("@").ifBlank { "Player" }

                repository.saveUser(
                    User(
                        userId = uid,
                        displayName = playerName,
                        email = email
                    )
                )
            }
        }
    }

    fun clearSnackBar() {
        _snackBarMessage.value = null
    }

    fun showMessage(msg: String) {
        _snackBarMessage.value = msg
    }

    fun selectTournament(tournament: Tournament?) {
        _selectedTournament.value = tournament
    }


    // Register into Tournament
    fun registerForTournament(
        tournamentId: String,
        inGameId: String,
        inGameName: String,
        slotNumber: Int,
        teamMembers: String,
        onSuccess: () -> Unit = {}
    ) {
        val user = currentUser.value ?: run {
            showMessage("Please log in first")
            return
        }

        viewModelScope.launch {
            val result = repository.registerForTournament(
                tournamentId = tournamentId,
                user = user,
                inGameId = inGameId.ifBlank { user.inGameIdFreeFire },
                inGameName = inGameName.ifBlank { user.inGameNameFreeFire },
                slotNumber = slotNumber,
                teamMembers = teamMembers
            )
            result.onSuccess { msg ->
                showMessage(msg)
                onSuccess()
            }.onFailure { err ->
                showMessage("Registration Failed: ${err.message}")
            }
        }
    }

    // Claim Daily Coins
    fun claimDailyReward() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.claimDailyReward(user.userId).onSuccess { amount ->
                showMessage("🎉 Claimed $amount Free Virtual Coins!")
            }.onFailure { err ->
                showMessage("Could not claim reward: ${err.message}")
            }
        }
    }

    // Update Profile
    fun updateProfile(
        displayName: String,
        email: String,
        phone: String,
        ffUid: String,
        ffIgn: String
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val updated = user.copy(
                displayName = displayName.ifBlank { user.displayName },
                email = email.ifBlank { user.email },
                phoneNumber = phone.ifBlank { user.phoneNumber },
                inGameIdFreeFire = ffUid.ifBlank { user.inGameIdFreeFire },
                inGameNameFreeFire = ffIgn.ifBlank { user.inGameNameFreeFire },
                updatedAt = System.currentTimeMillis()
            )
            repository.saveUser(updated).onSuccess {
                showMessage("Profile updated successfully!")
            }.onFailure {
                showMessage("Failed to update profile: ${it.message}")
            }
        }
    }

    // Submit Support Ticket
    fun submitSupportTicket(subject: String, message: String, onComplete: () -> Unit = {}) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.createTicket(user.userId, user.displayName, subject, message).onSuccess {
                showMessage("Support ticket submitted! Admin will respond shortly.")
                onComplete()
            }.onFailure {
                showMessage("Failed to submit ticket: ${it.message}")
            }
        }
    }

    // --- Admin Operations ---

    fun adminCreateTournament(
        title: String,
        game: String,
        category: String,
        mode: String,
        map: String,
        entryFee: Int,
        prizePool: Int,
        perKillCoins: Int,
        matchPoints: Int,
        matchTime: String,
        totalSlots: Int,
        rules: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            val t = Tournament(
                title = title,
                game = game,
                category = category,
                mode = mode,
                map = map,
                entryFeeCoins = entryFee,
                prizePoolCoins = prizePool,
                perKillCoins = perKillCoins,
                matchPoints = matchPoints,
                matchTime = matchTime,
                totalSlots = totalSlots,
                rules = rules,
                status = "UPCOMING"
            )
            repository.createTournament(t).onSuccess {
                showMessage("✅ Tournament '$title' created successfully!")
                onSuccess()
            }.onFailure {
                showMessage("Failed to create tournament: ${it.message}")
            }
        }
    }

    fun adminUpdateTournament(tournament: Tournament, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateTournament(tournament).onSuccess {
                showMessage("Tournament updated successfully")
                onSuccess()
            }.onFailure {
                showMessage("Failed to update tournament: ${it.message}")
            }
        }
    }

    fun adminDeleteTournament(id: String) {
        viewModelScope.launch {
            repository.deleteTournament(id).onSuccess {
                showMessage("Tournament deleted")
            }.onFailure {
                showMessage("Failed to delete tournament: ${it.message}")
            }
        }
    }

    fun adminSetRoomCredentials(
        tournamentId: String,
        roomId: String,
        roomPass: String,
        status: String
    ) {
        viewModelScope.launch {
            repository.updateRoomCredentials(tournamentId, roomId, roomPass, status).onSuccess {
                showMessage("Room ID & Password updated! Status set to $status")
            }.onFailure {
                showMessage("Failed to set room credentials: ${it.message}")
            }
        }
    }

    fun adminPublishResults(
        tournamentId: String,
        tournamentTitle: String,
        game: String,
        category: String,
        mode: String,
        winnerName: String,
        totalKills: Int,
        rankings: List<PlayerRankItem>,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.publishMatchResult(
                tournamentId = tournamentId,
                tournamentTitle = tournamentTitle,
                game = game,
                category = category,
                mode = mode,
                winnerName = winnerName,
                totalKills = totalKills,
                rankings = rankings
            ).onSuccess {
                showMessage("🏆 Match results published! Tournament marked COMPLETED.")
                onSuccess()
            }.onFailure {
                showMessage("Failed to publish results: ${it.message}")
            }
        }
    }

    fun adminAdjustCoins(userId: String, amount: Int, reason: String) {
        viewModelScope.launch {
            repository.adminModifyCoins(userId, amount, reason).onSuccess {
                showMessage("Coins adjusted successfully for user")
            }.onFailure {
                showMessage("Failed to adjust coins: ${it.message}")
            }
        }
    }

    fun adminToggleBan(user: User) {
        viewModelScope.launch {
            val newBannedState = !user.banned
            repository.setUserBanned(user.userId, newBannedState).onSuccess {
                showMessage(if (newBannedState) "Player ${user.displayName} banned!" else "Player ${user.displayName} unbanned!")
            }.onFailure {
                showMessage("Failed to change ban status: ${it.message}")
            }
        }
    }

    fun adminCreateAnnouncement(title: String, message: String, type: String) {
        viewModelScope.launch {
            repository.createAnnouncement(title, message, type).onSuccess {
                showMessage("Announcement broadcasted!")
            }.onFailure {
                showMessage("Failed to create announcement: ${it.message}")
            }
        }
    }
}
