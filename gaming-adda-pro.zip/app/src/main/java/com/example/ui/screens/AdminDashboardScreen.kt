package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayerRankItem
import com.example.data.model.Tournament
import com.example.data.model.User
import com.example.data.repository.GamingAddaRepository
import com.example.ui.components.GameCategoryBadge
import com.example.ui.components.StatusBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.GamingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: GamingViewModel,
    onBack: () -> Unit
) {
    val allTournaments by viewModel.allTournaments.collectAsState()
    val allUsers by viewModel.leaderboardUsers.collectAsState()
    val announcements by viewModel.announcements.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Tournaments", "Publish Results", "Room Credentials", "Players & Coins", "Broadcast")

    // State for Dialogs
    var showCreateTournamentDialog by remember { mutableStateOf(false) }
    var tournamentToEdit by remember { mutableStateOf<Tournament?>(null) }
    var tournamentForRoomCreds by remember { mutableStateOf<Tournament?>(null) }
    var tournamentForResults by remember { mutableStateOf<Tournament?>(null) }
    var userForCoinAdjust by remember { mutableStateOf<User?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = NeonRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ADMIN CONTROL PANEL",
                            color = NeonRed,
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            letterSpacing = 1.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = NeonCyan
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Admin Security Banner
            Surface(
                color = NeonRed.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, NeonRed.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🔒 Authenticated Admin UID: ${GamingAddaRepository.ADMIN_UID}",
                        color = NeonRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Tab bar
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = DarkSurface,
                contentColor = NeonCyan,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = NeonCyan
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp,
                                color = if (selectedTabIndex == index) NeonCyan else TextSecondary
                            )
                        }
                    )
                }
            }

            // Tab Content
            when (selectedTabIndex) {
                0 -> {
                    // Tournaments Tab (Create, Edit, Delete, Set Status)
                    AdminTournamentsTab(
                        tournaments = allTournaments,
                        onCreateClick = { showCreateTournamentDialog = true },
                        onEditClick = { tournamentToEdit = it },
                        onDeleteClick = { viewModel.adminDeleteTournament(it.id) },
                        onSetRoomClick = { tournamentForRoomCreds = it },
                        onPublishResultClick = { tournamentForResults = it }
                    )
                }
                1 -> {
                    // Results Tab
                    AdminPublishResultsTab(
                        tournaments = allTournaments,
                        onPublishClick = { tournamentForResults = it }
                    )
                }
                2 -> {
                    // Room Credentials Tab
                    AdminRoomCredentialsTab(
                        tournaments = allTournaments,
                        onSetRoomClick = { tournamentForRoomCreds = it }
                    )
                }
                3 -> {
                    // Players & Coins Tab
                    AdminPlayersTab(
                        users = allUsers,
                        onAdjustCoins = { userForCoinAdjust = it },
                        onToggleBan = { viewModel.adminToggleBan(it) }
                    )
                }
                4 -> {
                    // Announcements Broadcast Tab
                    AdminBroadcastTab(
                        announcements = announcements,
                        onCreateAnnouncement = { title, msg, type ->
                            viewModel.adminCreateAnnouncement(title, msg, type)
                        }
                    )
                }
            }
        }
    }

    // Dialog: Create Free Fire Tournament
    if (showCreateTournamentDialog) {
        CreateOrEditTournamentDialog(
            tournament = null,
            onDismiss = { showCreateTournamentDialog = false },
            onConfirm = { title, game, category, mode, map, entryFee, prizePool, perKill, matchPoints, matchTime, slots, rules ->
                viewModel.adminCreateTournament(
                    title, game, category, mode, map, entryFee, prizePool, perKill, matchPoints, matchTime, slots, rules
                ) {
                    showCreateTournamentDialog = false
                }
            }
        )
    }

    // Dialog: Edit Tournament
    tournamentToEdit?.let { tourney ->
        CreateOrEditTournamentDialog(
            tournament = tourney,
            onDismiss = { tournamentToEdit = null },
            onConfirm = { title, game, category, mode, map, entryFee, prizePool, perKill, matchPoints, matchTime, slots, rules ->
                viewModel.adminUpdateTournament(
                    tourney.copy(
                        title = title,
                        game = game,
                        category = category,
                        mode = mode,
                        map = map,
                        entryFeeCoins = entryFee,
                        prizePoolCoins = prizePool,
                        perKillCoins = perKill,
                        matchPoints = matchPoints,
                        matchTime = matchTime,
                        totalSlots = slots,
                        rules = rules
                    )
                ) {
                    tournamentToEdit = null
                }
            }
        )
    }

    // Dialog: Room Credentials & Status
    tournamentForRoomCreds?.let { tourney ->
        AdminRoomCredentialsDialog(
            tournament = tourney,
            onDismiss = { tournamentForRoomCreds = null },
            onSave = { roomId, pass, status ->
                viewModel.adminSetRoomCredentials(tourney.id, roomId, pass, status)
                tournamentForRoomCreds = null
            }
        )
    }

    // Dialog: Publish Match Results
    tournamentForResults?.let { tourney ->
        AdminPublishResultsDialog(
            tournament = tourney,
            onDismiss = { tournamentForResults = null },
            onPublish = { winnerName, totalKills, rankings ->
                viewModel.adminPublishResults(
                    tournamentId = tourney.id,
                    tournamentTitle = tourney.title,
                    game = tourney.game,
                    category = tourney.category,
                    mode = tourney.mode,
                    winnerName = winnerName,
                    totalKills = totalKills,
                    rankings = rankings
                ) {
                    tournamentForResults = null
                }
            }
        )
    }

    // Dialog: Virtual Coins Adjustment
    userForCoinAdjust?.let { user ->
        AdminAdjustCoinsDialog(
            user = user,
            onDismiss = { userForCoinAdjust = null },
            onAdjust = { amount, reason ->
                viewModel.adminAdjustCoins(user.userId, amount, reason)
                userForCoinAdjust = null
            }
        )
    }
}

// ----------------- TAB 1: Tournaments List -----------------
@Composable
fun AdminTournamentsTab(
    tournaments: List<Tournament>,
    onCreateClick: () -> Unit,
    onEditClick: (Tournament) -> Unit,
    onDeleteClick: (Tournament) -> Unit,
    onSetRoomClick: (Tournament) -> Unit,
    onPublishResultClick: (Tournament) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = onCreateClick,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = DarkBg)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CREATE NEW FREE FIRE TOURNAMENT",
                    color = DarkBg,
                    fontWeight = FontWeight.Black
                )
            }
        }

        items(tournaments, key = { it.id }) { t ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        GameCategoryBadge(game = t.game, category = t.category, mode = t.mode)
                        StatusBadge(status = t.status)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = t.title,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Text(
                        text = "Time: ${t.matchTime} • Slots: ${t.filledSlots}/${t.totalSlots} • Kill: +${t.perKillCoins} Coins • Match: +${t.matchPoints} Pts",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                    )

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onSetRoomClick(t) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.6f))
                        ) {
                            Text("Room ID & Pass", color = NeonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onPublishResultClick(t) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, NeonGold.copy(alpha = 0.6f))
                        ) {
                            Text("Results", color = NeonGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = { onEditClick(t) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = NeonCyan)
                        }

                        IconButton(
                            onClick = { onDeleteClick(t) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = NeonRed)
                        }
                    }
                }
            }
        }
    }
}

// ----------------- TAB 2: Publish Results -----------------
@Composable
fun AdminPublishResultsTab(
    tournaments: List<Tournament>,
    onPublishClick: (Tournament) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "SELECT TOURNAMENT TO PUBLISH RESULTS & RANKINGS",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(tournaments, key = { it.id }) { t ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            GameCategoryBadge(game = t.game, category = t.category, mode = t.mode)
                            Spacer(modifier = Modifier.width(6.dp))
                            StatusBadge(status = t.status)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = t.title,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Prize: ${t.prizePoolCoins} Coins • Kill: +${t.perKillCoins} Coins • Match: +${t.matchPoints} Pts",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = { onPublishClick(t) },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGold),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Publish", color = DarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ----------------- TAB 3: Room Credentials -----------------
@Composable
fun AdminRoomCredentialsTab(
    tournaments: List<Tournament>,
    onSetRoomClick: (Tournament) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "SET CUSTOM MATCH ROOM ID & PASSWORD",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(tournaments, key = { it.id }) { t ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, if (t.roomId.isNotBlank()) NeonGreen.copy(alpha = 0.5f) else DarkBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        GameCategoryBadge(game = t.game, category = t.category, mode = t.mode)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = t.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = if (t.roomId.isNotBlank()) "Room: ${t.roomId} | Pass: ${t.roomPassword}" else "Room credentials not set yet",
                            color = if (t.roomId.isNotBlank()) NeonGreen else NeonAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = { onSetRoomClick(t) },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Set Credentials", color = DarkBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ----------------- TAB 4: Players & Coins -----------------
@Composable
fun AdminPlayersTab(
    users: List<User>,
    onAdjustCoins: (User) -> Unit,
    onToggleBan: (User) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "REGISTERED PLAYERS & COIN BALANCES",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(users, key = { it.userId }) { user ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, if (user.banned) NeonRed else DarkBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user.displayName,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                if (user.banned) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = NeonRed.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "BANNED",
                                            color = NeonRed,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "UID: ${user.userId} • Free Fire: ${user.inGameNameFreeFire}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }

                        Text(
                            text = "${user.coinBalance} Coins",
                            color = NeonGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onAdjustCoins(user) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.6f))
                        ) {
                            Text("Credit / Debit Coins", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onToggleBan(user) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (user.banned) NeonGreen else NeonRed)
                        ) {
                            Text(
                                text = if (user.banned) "Unban Player" else "Ban Player",
                                color = if (user.banned) NeonGreen else NeonRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------- TAB 5: Broadcast Announcements -----------------
@Composable
fun AdminBroadcastTab(
    announcements: List<com.example.data.model.Announcement>,
    onCreateAnnouncement: (title: String, message: String, type: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("UPDATE") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "BROADCAST NEW ANNOUNCEMENT",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Headline / Title (e.g. Free Fire Registrations Open)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Message Body") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (title.isNotBlank() && message.isNotBlank()) {
                                onCreateAnnouncement(title, message, type)
                                title = ""
                                message = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Campaign, contentDescription = null, tint = DarkBg)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("BROADCAST ANNOUNCEMENT", color = DarkBg, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(
                text = "ACTIVE BROADCASTS (${announcements.size})",
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        items(announcements, key = { it.id }) { ann ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = ann.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = ann.message, color = TextSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}

// ----------------- DIALOGS -----------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateOrEditTournamentDialog(
    tournament: Tournament?,
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        game: String,
        category: String,
        mode: String,
        map: String,
        entryFee: Int,
        prizePool: Int,
        perKill: Int,
        matchPoints: Int,
        matchTime: String,
        slots: Int,
        rules: String
    ) -> Unit
) {
    var title by remember { mutableStateOf(tournament?.title ?: "") }
    var game by remember { mutableStateOf("Free Fire") }
    var category by remember { mutableStateOf(tournament?.category?.takeIf { it in listOf("CLASH_SQUAD", "LONE_WOLF", "CLASSIC") } ?: "LONE_WOLF") }
    var mode by remember { mutableStateOf(tournament?.mode ?: "Squad") }
    var map by remember { mutableStateOf(tournament?.map ?: if (category == "LONE_WOLF") "Iron Cage" else "Bermuda") }
    var entryFee by remember { mutableStateOf(tournament?.entryFeeCoins?.toString() ?: "20") }
    var prizePool by remember { mutableStateOf(tournament?.prizePoolCoins?.toString() ?: "250") }
    var perKill by remember { mutableStateOf(tournament?.perKillCoins?.toString() ?: "5") }
    var matchPoints by remember { mutableStateOf(tournament?.matchPoints?.toString() ?: "50") }
    var matchTime by remember { mutableStateOf(tournament?.matchTime ?: "Today, 09:00 PM") }
    var slots by remember { mutableStateOf(tournament?.totalSlots?.toString() ?: "16") }
    var rules by remember { mutableStateOf(tournament?.rules ?: "1. Strict anti-cheat enforcement.\n2. Room ID shared 15 mins before match.") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (tournament == null) "Create Free Fire Tournament" else "Edit Tournament",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Tournament Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                }

                // Game & Category Pickers
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Game", color = TextSecondary, fontSize = 11.sp)
                            Row {
                                Button(
                                    onClick = { game = "Free Fire"; category = "LONE_WOLF"; map = "Iron Cage" },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (game == "Free Fire") NeonCyan else DarkCardElevated
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Free Fire", color = if (game == "Free Fire") DarkBg else TextPrimary, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Category Buttons (LONE WOLF, CLASSIC, CLASH SQUAD)
                item {
                    Text("Category / Mode", color = TextSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val categories = listOf("CLASH_SQUAD", "LONE_WOLF", "CLASSIC")
                        categories.forEach { cat ->
                            Button(
                                onClick = { 
                                    category = cat 
                                    if (cat == "CLASH_SQUAD") {
                                        mode = "Squad"
                                        map = "Bermuda CS (Clock Tower)"
                                    } else if (cat == "LONE_WOLF") {
                                        mode = "Solo"
                                        map = "Iron Cage"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (category == cat) NeonCyan else DarkCardElevated
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = cat,
                                    color = if (category == cat) DarkBg else TextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Format: Solo, 1v1, Duo, Squad
                item {
                    Text("Format", color = TextSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Solo", "1v1", "Duo", "Squad").forEach { m ->
                            Button(
                                onClick = { mode = m },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (mode == m) NeonCyan else DarkCardElevated
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = m,
                                    color = if (mode == m) DarkBg else TextPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = map,
                        onValueChange = { map = it },
                        label = { Text("Map (e.g. Bermuda / Bermuda CS / Iron Cage)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = entryFee,
                            onValueChange = { entryFee = it },
                            label = { Text("Entry Coins") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = prizePool,
                            onValueChange = { prizePool = it },
                            label = { Text("Prize Coins") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = perKill,
                            onValueChange = { perKill = it },
                            label = { Text("Per Kill Coins") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = matchPoints,
                            onValueChange = { matchPoints = it },
                            label = { Text("Match / Win Pts") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = matchTime,
                            onValueChange = { matchTime = it },
                            label = { Text("Date & Time") },
                            modifier = Modifier.weight(1.2f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = slots,
                            onValueChange = { slots = it },
                            label = { Text("Total Slots") },
                            modifier = Modifier.weight(0.8f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = rules,
                        onValueChange = { rules = it },
                        label = { Text("Rules") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalTitle = title.ifBlank { "$game $category $mode Match" }
                    val entryFeeInt = entryFee.toIntOrNull() ?: 20
                    val prizePoolInt = prizePool.toIntOrNull() ?: 300
                    val perKillInt = perKill.toIntOrNull() ?: 5
                    val matchPointsInt = matchPoints.toIntOrNull() ?: 50
                    val slotsInt = slots.toIntOrNull() ?: 16

                    onConfirm(
                        finalTitle, game, category, mode, map, entryFeeInt, prizePoolInt, perKillInt, matchPointsInt, matchTime, slotsInt, rules
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
            ) {
                Text(if (tournament == null) "Create Match" else "Save Changes", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = DarkCard
    )
}

@Composable
fun AdminRoomCredentialsDialog(
    tournament: Tournament,
    onDismiss: () -> Unit,
    onSave: (roomId: String, pass: String, status: String) -> Unit
) {
    var roomId by remember { mutableStateOf(tournament.roomId) }
    var roomPass by remember { mutableStateOf(tournament.roomPassword) }
    var status by remember { mutableStateOf(tournament.status) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Set Room ID & Status for ${tournament.title}",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = roomId,
                    onValueChange = { roomId = it },
                    label = { Text("Custom Room ID (e.g. 5894321)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                OutlinedTextField(
                    value = roomPass,
                    onValueChange = { roomPass = it },
                    label = { Text("Custom Room Password (e.g. 123)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                Text("Match Status", color = TextSecondary, fontSize = 12.sp)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("UPCOMING", "LIVE", "COMPLETED", "CANCELLED").forEach { s ->
                        Button(
                            onClick = { status = s },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (status == s) NeonCyan else DarkCardElevated
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = s,
                                color = if (status == s) DarkBg else TextPrimary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(roomId, roomPass, status) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
            ) {
                Text("Save Credentials", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = DarkCard
    )
}

@Composable
fun AdminPublishResultsDialog(
    tournament: Tournament,
    onDismiss: () -> Unit,
    onPublish: (winnerName: String, totalKills: Int, rankings: List<PlayerRankItem>) -> Unit
) {
    var winnerName by remember { mutableStateOf("") }
    var totalKills by remember { mutableStateOf("40") }

    var p1Name by remember { mutableStateOf("Player 1 Team") }
    var p1Kills by remember { mutableStateOf("16") }
    var p1Pts by remember { mutableStateOf("${tournament.matchPoints}") }
    var p1Coins by remember { mutableStateOf("${(tournament.prizePoolCoins * 0.6).toInt()}") }

    var p2Name by remember { mutableStateOf("Player 2 Team") }
    var p2Kills by remember { mutableStateOf("12") }
    var p2Pts by remember { mutableStateOf("25") }
    var p2Coins by remember { mutableStateOf("${(tournament.prizePoolCoins * 0.3).toInt()}") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Publish Standings & Points for ${tournament.title}",
                color = NeonGold,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    OutlinedTextField(
                        value = winnerName,
                        onValueChange = { winnerName = it },
                        label = { Text("Winner Player / Team Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGold,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = totalKills,
                        onValueChange = { totalKills = it },
                        label = { Text("Total Match Kills") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGold,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )
                }

                item {
                    Text("Rank #1 Placement:", color = NeonGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = p1Name,
                            onValueChange = { p1Name = it },
                            label = { Text("Name") },
                            modifier = Modifier.weight(1.2f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = p1Kills,
                            onValueChange = { p1Kills = it },
                            label = { Text("Kills") },
                            modifier = Modifier.weight(0.8f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                            singleLine = true
                        )
                    }
                }

                item {
                    Text("Rank #2 Placement:", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(
                            value = p2Name,
                            onValueChange = { p2Name = it },
                            label = { Text("Name") },
                            modifier = Modifier.weight(1.2f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = p2Kills,
                            onValueChange = { p2Kills = it },
                            label = { Text("Kills") },
                            modifier = Modifier.weight(0.8f),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
                            singleLine = true
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalWinner = winnerName.ifBlank { p1Name }
                    val killsInt = totalKills.toIntOrNull() ?: 40

                    val rankings = listOf(
                        PlayerRankItem(
                            rank = 1,
                            playerName = p1Name,
                            kills = p1Kills.toIntOrNull() ?: 16,
                            killPoints = (p1Kills.toIntOrNull() ?: 16) * tournament.perKillCoins,
                            matchPoints = p1Pts.toIntOrNull() ?: tournament.matchPoints,
                            coinsWon = p1Coins.toIntOrNull() ?: (tournament.prizePoolCoins * 0.6).toInt()
                        ),
                        PlayerRankItem(
                            rank = 2,
                            playerName = p2Name,
                            kills = p2Kills.toIntOrNull() ?: 12,
                            killPoints = (p2Kills.toIntOrNull() ?: 12) * tournament.perKillCoins,
                            matchPoints = p2Pts.toIntOrNull() ?: 25,
                            coinsWon = p2Coins.toIntOrNull() ?: (tournament.prizePoolCoins * 0.3).toInt()
                        )
                    )

                    onPublish(finalWinner, killsInt, rankings)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGold)
            ) {
                Text("Publish Standings", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = DarkCard
    )
}

@Composable
fun AdminAdjustCoinsDialog(
    user: User,
    onDismiss: () -> Unit,
    onAdjust: (amount: Int, reason: String) -> Unit
) {
    var amount by remember { mutableStateOf("100") }
    var isCredit by remember { mutableStateOf(true) }
    var reason by remember { mutableStateOf("Match reward / compensation") }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Adjust Virtual Coins for ${user.displayName}",
                color = NeonGold,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Current Balance: ${user.coinBalance} Virtual Coins",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isCredit = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCredit) NeonGreen else DarkCardElevated
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CREDIT (+)", color = if (isCredit) DarkBg else TextPrimary, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { isCredit = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isCredit) NeonRed else DarkCardElevated
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("DEBIT (-)", color = if (!isCredit) DarkBg else TextPrimary, fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Coins Amount") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGold,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason for Coin Adjustment") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGold,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val raw = amount.toIntOrNull() ?: 0
                    val finalAmount = if (isCredit) raw else -raw
                    onAdjust(finalAmount, reason)
                },
                colors = ButtonDefaults.buttonColors(containerColor = if (isCredit) NeonGreen else NeonRed)
            ) {
                Text(if (isCredit) "Credit Coins" else "Debit Coins", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
            ) {
                Text("Cancel", color = TextSecondary)
            }
        },
        containerColor = DarkCard
    )
}
