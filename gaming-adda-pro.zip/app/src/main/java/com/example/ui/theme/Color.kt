package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Cyan Esports Palette
val DarkBg = Color(0xFF090D14)
val DarkSurface = Color(0xFF101726)
val DarkCard = Color(0xFF162033)
val DarkCardElevated = Color(0xFF1E2B45)
val DarkBorder = Color(0xFF223554)

val NeonCyan = Color(0xFF00F0FF)
val NeonCyanVariant = Color(0xFF00B4D8)
val NeonCyanGlow = Color(0x3300F0FF)

val NeonGreen = Color(0xFF00E676)
val NeonGold = Color(0xFFFFC107)
val NeonAmber = Color(0xFFFF9100)
val NeonRed = Color(0xFFFF1744)
val NeonPurple = Color(0xFF9D4EDD)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val FreeFireOrange = Color(0xFFFF5722)
val BgmiYellow = Color(0xFFF9A825)
val TdmCyan = Color(0xFF00E5FF)
val LoneWolfPurple = Color(0xFF7C4DFF)
