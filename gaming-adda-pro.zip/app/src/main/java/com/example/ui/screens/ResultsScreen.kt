package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MatchResult
import com.example.data.model.PlayerRankItem
import com.example.ui.components.GameCategoryBadge
import com.example.ui.components.NeonCoinBadge
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.LoneWolfPurple
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.GamingViewModel
import org.json.JSONArray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    viewModel: GamingViewModel,
    onWalletClick: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allResults by viewModel.allMatchResults.collectAsState()

    var selectedCategoryFilter by remember { mutableStateOf("ALL") }

    val filteredResults = remember(allResults, selectedCategoryFilter) {
        when (selectedCategoryFilter) {
            "ALL" -> allResults
            "CLASH_SQUAD" -> allResults.filter { it.category.equals("CLASH_SQUAD", true) }
            "LONE_WOLF" -> allResults.filter { it.category.equals("LONE_WOLF", true) }
            "FREE_FIRE" -> allResults.filter { it.game.equals("Free Fire", true) }
            else -> allResults
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "MATCH RESULTS",
                        color = TextPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        letterSpacing = 1.sp
                    )
                },
                actions = {
                    NeonCoinBadge(
                        coins = currentUser?.coinBalance ?: 0,
                        onClick = onWalletClick,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Filter row
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val filters = listOf(
                        "ALL" to "All Results",
                        "CLASH_SQUAD" to "FF Clash Squad (4v4)",
                        "LONE_WOLF" to "FF Lone Wolf",
                        "FREE_FIRE" to "Free Fire"
                    )

                    items(filters) { (key, label) ->
                        val isSelected = selectedCategoryFilter == key
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategoryFilter = key },
                            label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = DarkCard,
                                labelColor = TextSecondary,
                                selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                                selectedLabelColor = NeonCyan
                            ),
                            border = BorderStroke(1.dp, if (isSelected) NeonCyan else DarkBorder),
                            shape = RoundedCornerShape(20.dp)
                        )
                    }
                }
            }

            if (filteredResults.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No completed match results yet.\nResults will appear here as soon as tournaments finish!",
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                items(filteredResults, key = { it.id }) { result ->
                    MatchResultCard(result = result)
                }
            }
        }
    }
}

@Composable
fun MatchResultCard(result: MatchResult) {
    val isLoneWolf = result.category.equals("LONE_WOLF", ignoreCase = true)

    // Parse rankings from json
    val rankings = remember(result.rankingsJson) {
        val list = mutableListOf<PlayerRankItem>()
        try {
            if (result.rankingsJson.isNotBlank()) {
                val jsonArr = JSONArray(result.rankingsJson)
                for (i in 0 until jsonArr.length()) {
                    val obj = jsonArr.getJSONObject(i)
                    list.add(
                        PlayerRankItem(
                            rank = obj.optInt("rank", i + 1),
                            playerName = obj.optString("playerName", "Player"),
                            inGameId = obj.optString("inGameId", ""),
                            kills = obj.optInt("kills", 0),
                            killPoints = obj.optInt("killPoints", 0),
                            matchPoints = obj.optInt("matchPoints", 0),
                            coinsWon = obj.optInt("coinsWon", 0)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // fallback
        }
        list
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        border = BorderStroke(
            1.dp,
            if (isLoneWolf) LoneWolfPurple.copy(alpha = 0.5f) else DarkBorder
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GameCategoryBadge(
                    game = result.game,
                    category = result.category,
                    mode = result.mode
                )
                Text(
                    text = result.matchDate,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = result.tournamentTitle,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Winner Highlight Banner
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = NeonGold.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, NeonGold.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = "Winner",
                            tint = NeonGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = "MATCH WINNER", color = NeonGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = result.winnerName,
                                color = TextPrimary,
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp
                            )
                        }
                    }

                    if (result.totalKills > 0) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = DarkSurface
                        ) {
                            Text(
                                text = "${result.totalKills} Total Kills",
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Standings / Rankings Table
            if (rankings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "STANDINGS & KILL POINTS BREAKDOWN",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "#", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
                    Text(text = "PLAYER / TEAM", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(text = "KILLS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                    Text(text = "PTS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                    Text(text = "WON", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(55.dp))
                }

                // Table Rows
                rankings.forEachIndexed { index, item ->
                    val isFirst = item.rank == 1
                    val isSecond = item.rank == 2
                    val isThird = item.rank == 3

                    val rankColor = when {
                        isFirst -> NeonGold
                        isSecond -> Color(0xFFC0C0C0)
                        isThird -> Color(0xFFCD7F32)
                        else -> TextSecondary
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (index % 2 == 0) DarkCardElevated else DarkSurface)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "#${item.rank}",
                            color = rankColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.width(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.playerName,
                                color = TextPrimary,
                                fontWeight = if (isFirst) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp
                            )
                            if (item.inGameId.isNotBlank()) {
                                Text(text = "ID: ${item.inGameId}", color = TextMuted, fontSize = 9.sp)
                            }
                        }
                        Text(
                            text = "${item.kills}",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(42.dp)
                        )
                        Text(
                            text = "+${item.matchPoints + item.killPoints}",
                            color = NeonGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(42.dp)
                        )
                        Text(
                            text = "${item.coinsWon} C",
                            color = NeonGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(55.dp)
                        )
                    }
                }
            }
        }
    }
}
