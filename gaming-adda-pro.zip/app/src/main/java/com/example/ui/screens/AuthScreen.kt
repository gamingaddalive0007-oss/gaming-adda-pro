package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth

private val AuthBg = Color(0xFF080D16)
private val AuthCard = Color(0xFF151F2E)
private val AuthCyan = Color(0xFF00E5FF)

@Composable
fun AuthScreen(onAuthenticated: (String, String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val auth = remember { FirebaseAuth.getInstance() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AuthBg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AuthCard)
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "GAMING ADDA",
                    color = AuthCyan,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (isRegister) "CREATE ACCOUNT" else "WELCOME BACK",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(22.dp))
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))

                if (message.isNotBlank()) {
                    Text(message, color = Color(0xFFFF8A80))
                    Spacer(Modifier.height(10.dp))
                }

                Button(
                    onClick = {
                        val cleanEmail = email.trim()
                        if (cleanEmail.isBlank() || password.isBlank()) {
                            message = "Email और Password भरो।"
                        } else if (password.length < 6) {
                            message = "Password कम से कम 6 अक्षर का होना चाहिए।"
                        } else {
                            loading = true
                            message = ""
                            val task = if (isRegister) {
                                auth.createUserWithEmailAndPassword(cleanEmail, password)
                            } else {
                                auth.signInWithEmailAndPassword(cleanEmail, password)
                            }
                            task.addOnCompleteListener { result ->
                                loading = false
                                if (result.isSuccessful) {
                                    val user = auth.currentUser
                                    if (user != null) {
                                        onAuthenticated(user.uid, user.email ?: cleanEmail)
                                    } else {
                                        message = "Account नहीं मिला। दोबारा कोशिश करो।"
                                    }
                                } else {
                                    message = result.exception?.localizedMessage
                                        ?: "Login नहीं हुआ। दोबारा कोशिश करो।"
                                }
                            }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AuthCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (loading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.Black
                        )
                    } else {
                        Text(
                            if (isRegister) "CREATE ACCOUNT" else "LOGIN",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                TextButton(
                    onClick = {
                        isRegister = !isRegister
                        message = ""
                    },
                    enabled = !loading
                ) {
                    Text(
                        if (isRegister) "Already have an account? LOGIN"
                        else "New player? CREATE ACCOUNT",
                        color = AuthCyan
                    )
                }
            }
        }
    }
}
