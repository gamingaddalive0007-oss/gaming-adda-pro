package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Tournament
import com.example.ui.components.NeonCoinBadge
import com.example.ui.components.TournamentCard
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardElevated
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.FreeFireOrange
import com.example.ui.theme.LoneWolfPurple
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TdmCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.GamingViewModel

enum class TournamentFilter(val label: String) {
    ALL("All Matches"),
    FF_CLASH_SQUAD("FF Clash Squad (4v4)"),
    BGMI_TDM("BGMI TDM"),
    FF_LONE_WOLF("FF Lone Wolf"),
    BGMI_CLASSIC("BGMI Classic"),
    FF_BR("Free Fire BR")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: GamingViewModel,
    onTournamentClick: (Tournament) -> Unit,
    onWalletClick: () -> Unit,
    onAdminClick: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allTournaments by viewModel.allTournaments.collectAsState()
    val myParticipants by viewModel.myParticipants.collectAsState()
    val announcements by viewModel.announcements.collectAsState()
    val isAdmin by viewModel.isAdmin.collectAsState()

    var selectedFilter by remember { mutableStateOf(TournamentFilter.ALL) }
    var showAnnouncementsDialog by remember { mutableStateOf(false) }

    val registeredIds = remember(myParticipants) {
        myParticipants.map { it.tournamentId }.toSet()
    }

    val filteredTournaments = remember(allTournaments, selectedFilter) {
        when (selectedFilter) {
            TournamentFilter.ALL -> allTournaments
            TournamentFilter.FF_CLASH_SQUAD -> allTournaments.filter {
                it.game.equals("Free Fire", true) && it.category.equals("CLASH_SQUAD", true)
            }
            TournamentFilter.BGMI_TDM -> allTournaments.filter {
                it.game.equals("BGMI", true) && it.category.equals("TDM", true)
            }
            TournamentFilter.FF_LONE_WOLF -> allTournaments.filter {
                it.game.equals("Free Fire", true) && it.category.equals("LONE_WOLF", true)
            }
            TournamentFilter.BGMI_CLASSIC -> allTournaments.filter {
                it.game.equals("BGMI", true) && it.category.equals("CLASSIC", true)
            }
            TournamentFilter.FF_BR -> allTournaments.filter {
                it.game.equals("Free Fire", true) && it.category.equals("CLASSIC", true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "GAMING",
                            color = TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ADDA",
                            color = NeonCyan,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            letterSpacing = 1.sp
                        )
                    }
                },
                actions = {
                    if (isAdmin) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = NeonRed.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, NeonRed),
                            modifier = Modifier
                                .clickable { onAdminClick() }
                                .padding(end = 8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Admin",
                                    tint = NeonRed,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "ADMIN",
                                    color = NeonRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    NeonCoinBadge(
                        coins = currentUser?.coinBalance ?: 0,
                        onClick = onWalletClick,
                        modifier = Modifier.padding(end = 8.dp)
                    )

                    IconButton(onClick = { showAnnouncementsDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = "Announcements",
                            tint = if (announcements.isNotEmpty()) NeonCyan else TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            // Announcements marquee
            if (announcements.isNotEmpty()) {
                item {
                    val latest = announcements.first()
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showAnnouncementsDialog = true },
                        color = DarkCardElevated,
                        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FlashOn,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${latest.title}: ${latest.message}",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Featured Hero Card: BGMI TDM Feature
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = BorderStroke(
                        1.5.dp,
                        Brush.horizontalGradient(listOf(NeonCyan, Color(0xFF0077B6), LoneWolfPurple))
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🔥 NEW TOURNAMENT MODES",
                                color = NeonAmber,
                                fontWeight = FontWeight.Black,
                                fontSize = 11.sp,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = NeonCyan.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "KILL POINTS + SLOTS",
                                    color = NeonCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "BGMI TDM & Free Fire (Lone Wolf & Clash Squad)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )

                        Text(
                            text = "BGMI 4v4 TDM, Free Fire Clash Squad 4v4 & 1v1 Gladiator duels with dynamic kill rewards and match points.",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { selectedFilter = TournamentFilter.FF_CLASH_SQUAD },
                                colors = ButtonDefaults.buttonColors(containerColor = FreeFireOrange),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "FF Clash Squad (4v4)",
                                    color = DarkBg,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }

                            Button(
                                onClick = { selectedFilter = TournamentFilter.BGMI_TDM },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "BGMI TDM (4v4)",
                                    color = DarkBg,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }

                            Button(
                                onClick = { selectedFilter = TournamentFilter.FF_LONE_WOLF },
                                colors = ButtonDefaults.buttonColors(containerColor = LoneWolfPurple),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "FF Lone Wolf",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Category Filter Chips
            item {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(TournamentFilter.values()) { filter ->
                        val isSelected = selectedFilter == filter
                        val chipColor = when (filter) {
                            TournamentFilter.FF_CLASH_SQUAD -> FreeFireOrange
                            TournamentFilter.BGMI_TDM -> TdmCyan
                            TournamentFilter.FF_LONE_WOLF -> LoneWolfPurple
                            else -> NeonCyan
                        }

                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedFilter = filter },
                            label = {
                                Text(
                                    text = filter.label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = DarkCard,
                                labelColor = TextSecondary,
                                selectedContainerColor = chipColor.copy(alpha = 0.2f),
                                selectedLabelColor = chipColor
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (isSelected) chipColor else DarkBorder
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                    }
                }
            }

            // Tournament count header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AVAILABLE TOURNAMENTS",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${filteredTournaments.size} Matches",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Tournaments List
            if (filteredTournaments.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No tournaments available for this category.\nCheck back shortly or view other modes!",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                items(filteredTournaments, key = { it.id }) { tournament ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                        TournamentCard(
                            tournament = tournament,
                            isRegistered = registeredIds.contains(tournament.id),
                            onClick = { onTournamentClick(tournament) }
                        )
                    }
                }
            }
        }
    }

    // Announcements Dialog
    if (showAnnouncementsDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showAnnouncementsDialog = false },
            title = {
                Text(
                    text = "Announcements & Alerts",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (announcements.isEmpty()) {
                        Text("No announcements at this time.", color = TextSecondary)
                    } else {
                        announcements.forEach { ann ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkCardElevated),
                                border = BorderStroke(1.dp, DarkBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = ann.title,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = ann.message,
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAnnouncementsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan)
                ) {
                    Text("Close", color = DarkBg, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkCard
        )
    }
}
