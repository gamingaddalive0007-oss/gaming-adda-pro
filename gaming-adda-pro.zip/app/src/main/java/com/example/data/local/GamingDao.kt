package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Announcement
import com.example.data.model.CoinTransaction
import com.example.data.model.MatchResult
import com.example.data.model.Participant
import com.example.data.model.SupportTicket
import com.example.data.model.Tournament
import com.example.data.model.User
import kotlinx.coroutines.flow.Flow

@Dao
interface GamingDao {

    // Tournaments
    @Query("SELECT * FROM tournaments ORDER BY createdAt DESC")
    fun getAllTournamentsFlow(): Flow<List<Tournament>>

    @Query("SELECT * FROM tournaments WHERE game = :game ORDER BY createdAt DESC")
    fun getTournamentsByGame(game: String): Flow<List<Tournament>>

    @Query("SELECT * FROM tournaments WHERE category = :category ORDER BY createdAt DESC")
    fun getTournamentsByCategory(category: String): Flow<List<Tournament>>

    @Query("SELECT * FROM tournaments WHERE id = :id")
    fun getTournamentById(id: String): Flow<Tournament?>

    @Query("SELECT * FROM tournaments WHERE id = :id")
    suspend fun getTournamentByIdOnce(id: String): Tournament?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournament(tournament: Tournament)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTournaments(tournaments: List<Tournament>)

    @Update
    suspend fun updateTournament(tournament: Tournament)

    @Query("DELETE FROM tournaments WHERE id = :id")
    suspend fun deleteTournament(id: String)

    @Query("UPDATE tournaments SET filledSlots = :filledSlots WHERE id = :tournamentId")
    suspend fun updateSlots(tournamentId: String, filledSlots: Int)

    @Query("UPDATE tournaments SET roomId = :roomId, roomPassword = :roomPassword, status = :status WHERE id = :tournamentId")
    suspend fun updateRoomCredentials(tournamentId: String, roomId: String, roomPassword: String, status: String)

    @Query("UPDATE tournaments SET status = :status WHERE id = :tournamentId")
    suspend fun updateTournamentStatus(tournamentId: String, status: String)

    // Participants
    @Query("SELECT * FROM participants WHERE tournamentId = :tournamentId ORDER BY slotNumber ASC")
    fun getParticipantsForTournament(tournamentId: String): Flow<List<Participant>>

    @Query("SELECT * FROM participants WHERE userId = :userId ORDER BY joinedAt DESC")
    fun getParticipantsForUser(userId: String): Flow<List<Participant>>

    @Query("SELECT * FROM participants WHERE tournamentId = :tournamentId AND userId = :userId LIMIT 1")
    suspend fun getParticipant(tournamentId: String, userId: String): Participant?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParticipant(participant: Participant)

    @Query("DELETE FROM participants WHERE id = :id")
    suspend fun deleteParticipant(id: String)

    // Users
    @Query("SELECT * FROM users WHERE userId = :userId")
    fun getUserById(userId: String): Flow<User?>

    @Query("SELECT * FROM users WHERE userId = :userId")
    suspend fun getUserByIdOnce(userId: String): User?

    @Query("SELECT * FROM users ORDER BY totalWins DESC, totalKills DESC")
    fun getAllUsersFlow(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Query("UPDATE users SET coinBalance = :newBalance WHERE userId = :userId")
    suspend fun updateCoinBalance(userId: String, newBalance: Int)

    @Query("UPDATE users SET banned = :banned WHERE userId = :userId")
    suspend fun setUserBanned(userId: String, banned: Boolean)

    // Match Results
    @Query("SELECT * FROM match_results ORDER BY createdAt DESC")
    fun getAllMatchResultsFlow(): Flow<List<MatchResult>>

    @Query("SELECT * FROM match_results WHERE game = :game ORDER BY createdAt DESC")
    fun getMatchResultsByGame(game: String): Flow<List<MatchResult>>

    @Query("SELECT * FROM match_results WHERE id = :id")
    fun getMatchResultById(id: String): Flow<MatchResult?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatchResult(result: MatchResult)

    @Query("DELETE FROM match_results WHERE id = :id")
    suspend fun deleteMatchResult(id: String)

    // Coin Transactions
    @Query("SELECT * FROM coin_transactions WHERE userId = :userId ORDER BY createdAt DESC")
    fun getTransactionsForUser(userId: String): Flow<List<CoinTransaction>>

    @Query("SELECT * FROM coin_transactions ORDER BY createdAt DESC")
    fun getAllTransactions(): Flow<List<CoinTransaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: CoinTransaction)

    // Announcements
    @Query("SELECT * FROM announcements ORDER BY createdAt DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncement(id: String)

    // Support Tickets
    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun getAllTickets(): Flow<List<SupportTicket>>

    @Query("SELECT * FROM support_tickets WHERE userId = :userId ORDER BY createdAt DESC")
    fun getTicketsForUser(userId: String): Flow<List<SupportTicket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: SupportTicket)

    @Query("UPDATE support_tickets SET status = :status WHERE id = :ticketId")
    suspend fun updateTicketStatus(ticketId: String, status: String)
}
