package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "participants")
data class Participant(
    @PrimaryKey
    val id: String = "",
    val tournamentId: String = "",
    val userId: String = "",
    val userName: String = "",
    val inGameId: String = "",
    val inGameName: String = "",
    val slotNumber: Int = 1,
    val teamMembers: String = "", // Comma-separated or formatted names
    val joinedAt: Long = System.currentTimeMillis()
)
