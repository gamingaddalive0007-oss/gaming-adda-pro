package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tournaments")
data class Tournament(
    @PrimaryKey
    val id: String = "",
    val title: String = "",
    val game: String = "Free Fire",
    val category: String = "CLASSIC", // "CLASSIC", "LONE_WOLF", "CLASH_SQUAD"
    val mode: String = "Squad", // "Solo", "1v1", "Duo", "Squad"
    val map: String = "Erangel",
    val entryFeeCoins: Int = 20,
    val prizePoolCoins: Int = 300,
    val perKillCoins: Int = 5,
    val matchPoints: Int = 50, // Win points / Booyah points
    val matchTime: String = "Today, 08:00 PM",
    val totalSlots: Int = 25,
    val filledSlots: Int = 0,
    val status: String = "UPCOMING", // "UPCOMING", "LIVE", "COMPLETED", "CANCELLED"
    val bannerUrl: String = "",
    val roomId: String = "", // Revealed to registered players only
    val roomPassword: String = "", // Revealed to registered players only
    val rules: String = "1. Emulators strictly prohibited.\n2. Hacks or third-party tools lead to instant permanent ban.\n3. Join room 15 mins before match time.",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
