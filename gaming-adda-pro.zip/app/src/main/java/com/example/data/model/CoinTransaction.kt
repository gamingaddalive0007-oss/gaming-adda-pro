package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "coin_transactions")
data class CoinTransaction(
    @PrimaryKey
    val id: String = "",
    val userId: String = "",
    val type: String = "SIGNUP_BONUS", // "SIGNUP_BONUS", "DAILY_REWARD", "TOURNAMENT_JOIN", "TOURNAMENT_WIN", "ADMIN_CREDIT", "ADMIN_DEBIT"
    val amount: Int = 0, // Positive for credit, negative for debit
    val description: String = "",
    val tournamentId: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
