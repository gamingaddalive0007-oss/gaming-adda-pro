package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class PlayerRankItem(
    val rank: Int = 1,
    val playerName: String = "",
    val inGameId: String = "",
    val kills: Int = 0,
    val killPoints: Int = 0,
    val matchPoints: Int = 0,
    val coinsWon: Int = 0
)

@Entity(tableName = "match_results")
data class MatchResult(
    @PrimaryKey
    val id: String = "",
    val tournamentId: String = "",
    val tournamentTitle: String = "",
    val game: String = "Free Fire",
    val category: String = "CLASSIC",
    val mode: String = "Squad",
    val matchDate: String = "",
    val winnerName: String = "",
    val totalKills: Int = 0,
    val rankingsJson: String = "", // JSON serialized list of PlayerRankItem
    val createdAt: Long = System.currentTimeMillis()
)
