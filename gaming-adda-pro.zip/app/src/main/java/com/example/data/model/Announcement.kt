package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val type: String = "UPDATE", // "UPDATE", "ALERT", "TOURNAMENT"
    val createdAt: Long = System.currentTimeMillis()
)
