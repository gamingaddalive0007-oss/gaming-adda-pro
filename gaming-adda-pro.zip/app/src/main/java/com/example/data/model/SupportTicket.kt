package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "support_tickets")
data class SupportTicket(
    @PrimaryKey
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val subject: String = "",
    val message: String = "",
    val status: String = "OPEN", // "OPEN", "RESOLVED"
    val createdAt: Long = System.currentTimeMillis()
)
