package com.example.data.repository

import android.content.Context
import com.example.data.local.GamingDao
import com.example.data.local.GamingDatabase
import com.example.data.model.Announcement
import com.example.data.model.CoinTransaction
import com.example.data.model.MatchResult
import com.example.data.model.Participant
import com.example.data.model.PlayerRankItem
import com.example.data.model.SupportTicket
import com.example.data.model.Tournament
import com.example.data.model.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class GamingAddaRepository(
    private val dao: GamingDao
) {
    companion object {
        const val ADMIN_UID = "o8z2rP2rtyey2LFuauBsCQly1eq1"

        @Volatile
        private var instance: GamingAddaRepository? = null

        fun getInstance(context: Context): GamingAddaRepository {
            return instance ?: synchronized(this) {
                val db = GamingDatabase.getDatabase(context)
                val repo = GamingAddaRepository(db.gamingDao())
                instance = repo
                repo
            }
        }
    }

    // --- Tournaments ---
    fun getAllTournaments(): Flow<List<Tournament>> = dao.getAllTournamentsFlow()
    fun getTournamentsByGame(game: String): Flow<List<Tournament>> = dao.getTournamentsByGame(game)
    fun getTournamentsByCategory(category: String): Flow<List<Tournament>> = dao.getTournamentsByCategory(category)
    fun getTournamentById(id: String): Flow<Tournament?> = dao.getTournamentById(id)

    suspend fun createTournament(tournament: Tournament): Result<String> = withContext(Dispatchers.IO) {
        try {
            val id = if (tournament.id.isBlank()) UUID.randomUUID().toString() else tournament.id
            val finalTourney = tournament.copy(
                id = id,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            dao.insertTournament(finalTourney)
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateTournament(tournament: Tournament): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.updateTournament(tournament.copy(updatedAt = System.currentTimeMillis()))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTournament(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.deleteTournament(id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateRoomCredentials(
        tournamentId: String,
        roomId: String,
        roomPass: String,
        status: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.updateRoomCredentials(tournamentId, roomId, roomPass, status)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateTournamentStatus(tournamentId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.updateTournamentStatus(tournamentId, status)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Registration & Slots ---
    fun getParticipantsForTournament(tournamentId: String): Flow<List<Participant>> =
        dao.getParticipantsForTournament(tournamentId)

    fun getParticipantsForUser(userId: String): Flow<List<Participant>> =
        dao.getParticipantsForUser(userId)

    suspend fun registerForTournament(
        tournamentId: String,
        user: User,
        inGameId: String,
        inGameName: String,
        slotNumber: Int,
        teamMembers: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val tournament = dao.getTournamentByIdOnce(tournamentId)
                ?: return@withContext Result.failure(Exception("Tournament not found"))

            if (tournament.status != "UPCOMING") {
                return@withContext Result.failure(Exception("Registration closed. Match is ${tournament.status}"))
            }

            if (tournament.filledSlots >= tournament.totalSlots) {
                return@withContext Result.failure(Exception("All tournament slots are filled!"))
            }

            val existing = dao.getParticipant(tournamentId, user.userId)
            if (existing != null) {
                return@withContext Result.failure(Exception("You have already registered for this tournament!"))
            }

            // Check coin balance
            if (user.coinBalance < tournament.entryFeeCoins) {
                return@withContext Result.failure(
                    Exception("Insufficient RD Coins! Entry fee: ${tournament.entryFeeCoins} Coins, Your balance: ${user.coinBalance} Coins")
                )
            }

            // Deduct entry fee
            val newBalance = user.coinBalance - tournament.entryFeeCoins
            dao.updateCoinBalance(user.userId, newBalance)

            // Log Transaction
            val txId = UUID.randomUUID().toString()
            dao.insertTransaction(
                CoinTransaction(
                    id = txId,
                    userId = user.userId,
                    type = "TOURNAMENT_JOIN",
                    amount = -tournament.entryFeeCoins,
                    description = "Entry fee for ${tournament.title}",
                    tournamentId = tournament.id
                )
            )

            // Create participant
            val partId = UUID.randomUUID().toString()
            dao.insertParticipant(
                Participant(
                    id = partId,
                    tournamentId = tournamentId,
                    userId = user.userId,
                    userName = user.displayName,
                    inGameId = inGameId,
                    inGameName = inGameName,
                    slotNumber = slotNumber,
                    teamMembers = teamMembers,
                    joinedAt = System.currentTimeMillis()
                )
            )

            // Increment filled slots
            val newFilledSlots = tournament.filledSlots + 1
            dao.updateSlots(tournamentId, newFilledSlots)

            // Update user stats
            dao.updateUser(user.copy(
                coinBalance = newBalance,
                totalMatches = user.totalMatches + 1
            ))

            Result.success("Slot #$slotNumber successfully booked!")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Users & Profiles ---
    fun getUser(userId: String): Flow<User?> = dao.getUserById(userId)
    fun getAllUsers(): Flow<List<User>> = dao.getAllUsersFlow()

    suspend fun saveUser(user: User): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.insertUser(user)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }



    suspend fun adminModifyCoins(userId: String, amount: Int, reason: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val user = dao.getUserByIdOnce(userId) ?: return@withContext Result.failure(Exception("User not found"))
            val newBalance = (user.coinBalance + amount).coerceAtLeast(0)
            dao.updateCoinBalance(userId, newBalance)
            val type = if (amount >= 0) "ADMIN_CREDIT" else "ADMIN_DEBIT"
            dao.insertTransaction(
                CoinTransaction(
                    id = UUID.randomUUID().toString(),
                    userId = userId,
                    type = type,
                    amount = amount,
                    description = "Admin action: $reason"
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setUserBanned(userId: String, banned: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.setUserBanned(userId, banned)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Match Results ---
    fun getAllMatchResults(): Flow<List<MatchResult>> = dao.getAllMatchResultsFlow()
    fun getMatchResultsByGame(game: String): Flow<List<MatchResult>> = dao.getMatchResultsByGame(game)
    fun getMatchResultById(id: String): Flow<MatchResult?> = dao.getMatchResultById(id)

    suspend fun publishMatchResult(
        tournamentId: String,
        tournamentTitle: String,
        game: String,
        category: String,
        mode: String,
        winnerName: String,
        totalKills: Int,
        rankings: List<PlayerRankItem>
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            // Convert rankings to JSON
            val jsonArray = JSONArray()
            rankings.forEach { item ->
                val obj = JSONObject()
                obj.put("rank", item.rank)
                obj.put("playerName", item.playerName)
                obj.put("inGameId", item.inGameId)
                obj.put("kills", item.kills)
                obj.put("killPoints", item.killPoints)
                obj.put("matchPoints", item.matchPoints)
                obj.put("coinsWon", item.coinsWon)
                jsonArray.put(obj)
            }

            val resultId = UUID.randomUUID().toString()
            val matchResult = MatchResult(
                id = resultId,
                tournamentId = tournamentId,
                tournamentTitle = tournamentTitle,
                game = game,
                category = category,
                mode = mode,
                matchDate = "Just Now",
                winnerName = winnerName,
                totalKills = totalKills,
                rankingsJson = jsonArray.toString()
            )
            dao.insertMatchResult(matchResult)

            // Mark tournament as completed
            dao.updateTournamentStatus(tournamentId, "COMPLETED")

            Result.success(resultId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMatchResult(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.deleteMatchResult(id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Coin Transactions ---
    fun getTransactionsForUser(userId: String): Flow<List<CoinTransaction>> = dao.getTransactionsForUser(userId)
    fun getAllTransactions(): Flow<List<CoinTransaction>> = dao.getAllTransactions()

    // --- Announcements ---
    fun getAllAnnouncements(): Flow<List<Announcement>> = dao.getAllAnnouncements()
    suspend fun createAnnouncement(title: String, message: String, type: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val ann = Announcement(
                id = UUID.randomUUID().toString(),
                title = title,
                message = message,
                type = type
            )
            dao.insertAnnouncement(ann)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    suspend fun deleteAnnouncement(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.deleteAnnouncement(id)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- Support Tickets ---
    fun getTicketsForUser(userId: String): Flow<List<SupportTicket>> = dao.getTicketsForUser(userId)
    fun getAllTickets(): Flow<List<SupportTicket>> = dao.getAllTickets()
    suspend fun createTicket(userId: String, userName: String, subject: String, message: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val ticket = SupportTicket(
                id = UUID.randomUUID().toString(),
                userId = userId,
                userName = userName,
                subject = subject,
                message = message,
                status = "OPEN"
            )
            dao.insertTicket(ticket)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    suspend fun updateTicketStatus(ticketId: String, status: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            dao.updateTicketStatus(ticketId, status)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
