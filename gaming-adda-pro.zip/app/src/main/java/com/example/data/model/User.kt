package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val inGameIdFreeFire: String = "",
    val inGameNameFreeFire: String = "",
    val inGameIdBgmi: String = "",
    val inGameNameBgmi: String = "",
    val avatarUrl: String = "avatar_1",
    val coinBalance: Int = 0,
    val role: String = "player", // "admin" or "player"
    val totalMatches: Int = 0,
    val totalKills: Int = 0,
    val totalWins: Int = 0,
    val banned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
