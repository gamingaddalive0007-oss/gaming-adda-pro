package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.Announcement
import com.example.data.model.CoinTransaction
import com.example.data.model.MatchResult
import com.example.data.model.Participant
import com.example.data.model.SupportTicket
import com.example.data.model.Tournament
import com.example.data.model.User

@Database(
    entities = [
        User::class,
        Tournament::class,
        Participant::class,
        MatchResult::class,
        CoinTransaction::class,
        Announcement::class,
        SupportTicket::class
    ],
    version = 2,
    exportSchema = false
)
abstract class GamingDatabase : RoomDatabase() {

    abstract fun gamingDao(): GamingDao

    companion object {
        @Volatile
        private var INSTANCE: GamingDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    DELETE FROM participants
                    WHERE tournamentId IN (
                        'ff_lonewolf_solo_01',
                        'ff_lonewolf_duo_02',
                        'ff_br_squad_01',
                        'ff_cs_squad_01'
                    )
                    OR userId IN (
                        'player_user_123',
                        'player_top_1',
                        'player_top_2',
                        'player_top_3'
                    )
                """.trimIndent())

                db.execSQL("""
                    DELETE FROM match_results
                    WHERE id IN ('result_wolf_01', 'result_cs_01')
                """.trimIndent())

                db.execSQL("""
                    DELETE FROM coin_transactions
                    WHERE id IN ('tx_welcome', 'tx_daily')
                """.trimIndent())

                db.execSQL("""
                    DELETE FROM announcements
                    WHERE id IN ('ann_free_fire_update', 'ann_rules')
                """.trimIndent())

                db.execSQL("""
                    DELETE FROM tournaments
                    WHERE id IN (
                        'ff_lonewolf_solo_01',
                        'ff_lonewolf_duo_02',
                        'ff_br_squad_01',
                        'ff_cs_squad_01'
                    )
                """.trimIndent())

                db.execSQL("""
                    DELETE FROM users
                    WHERE userId IN (
                        'player_user_123',
                        'player_top_1',
                        'player_top_2',
                        'player_top_3'
                    )
                """.trimIndent())

                db.execSQL("""
                    UPDATE users
                    SET coinBalance = 0,
                        totalMatches = 0,
                        totalKills = 0,
                        totalWins = 0,
                        role = 'admin'
                    WHERE userId = 'o8z2rP2rtyey2LFuauBsCQly1eq1'
                """.trimIndent())
            }
        }

        fun getDatabase(context: Context): GamingDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GamingDatabase::class.java,
                    "gaming_adda_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
