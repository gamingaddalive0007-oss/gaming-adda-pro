package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.Announcement
import com.example.data.model.CoinTransaction
import com.example.data.model.MatchResult
import com.example.data.model.Participant
import com.example.data.model.SupportTicket
import com.example.data.model.Tournament
import com.example.data.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Tournament::class,
        Participant::class,
        MatchResult::class,
        CoinTransaction::class,
        Announcement::class,
        SupportTicket::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GamingDatabase : RoomDatabase() {
    abstract fun gamingDao(): GamingDao

    companion object {
        @Volatile
        private var INSTANCE: GamingDatabase? = null

        fun getDatabase(context: Context): GamingDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GamingDatabase::class.java,
                    "gaming_adda_database"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        seedDatabase(database.gamingDao())
                    }
                }
            }
        }

        suspend fun seedDatabase(dao: GamingDao) {
            // Seed Admin User
            val adminUid = "o8z2rP2rtyey2LFuauBsCQly1eq1"
            dao.insertUser(
                User(
                    userId = adminUid,
                    displayName = "Gaming Adda Admin",
                    email = "admin@gamingadda.com",
                    phoneNumber = "9876543210",
                    inGameIdFreeFire = "109876543",
                    inGameNameFreeFire = "ADDAxBOSS",
                    avatarUrl = "avatar_admin",
                    coinBalance = 50000,
                    role = "admin",
                    totalMatches = 150,
                    totalKills = 740,
                    totalWins = 65
                )
            )

            // Seed Default Player (active player for demo)
            val demoPlayerUid = "player_user_123"
            dao.insertUser(
                User(
                    userId = demoPlayerUid,
                    displayName = "CyberStriker",
                    email = "cyberstriker@gmail.com",
                    phoneNumber = "9988776655",
                    inGameIdFreeFire = "887766554",
                    inGameNameFreeFire = "CYBERxSHOT",
                    avatarUrl = "avatar_1",
                    coinBalance = 250,
                    role = "player",
                    totalMatches = 32,
                    totalKills = 148,
                    totalWins = 9
                )
            )

            // Seed other Leaderboard Players
            dao.insertUser(
                User(
                    userId = "player_top_1",
                    displayName = "ApexPredator",
                    email = "apex@esports.com",
                    coinBalance = 1840,
                    role = "player",
                    totalMatches = 85,
                    totalKills = 430,
                    totalWins = 28
                )
            )
            dao.insertUser(
                User(
                    userId = "player_top_2",
                    displayName = "ViperSniper",
                    email = "viper@gaming.com",
                    inGameIdFreeFire = "776655443",
                    inGameNameFreeFire = "VIPERx99",
                    coinBalance = 1420,
                    role = "player",
                    totalMatches = 64,
                    totalKills = 310,
                    totalWins = 21
                )
            )
            dao.insertUser(
                User(
                    userId = "player_top_3",
                    displayName = "ShadowNinja",
                    email = "ninja@stream.com",
                    coinBalance = 980,
                    role = "player",
                    totalMatches = 50,
                    totalKills = 220,
                    totalWins = 14
                )
            )

            // Seed Initial Free Fire Tournaments
            val tournaments = listOf(
                // 3. Free Fire Lone Wolf - Solo 1v1
                Tournament(
                    id = "ff_lonewolf_solo_01",
                    title = "Free Fire Lone Wolf 1v1 Showdown",
                    game = "Free Fire",
                    category = "LONE_WOLF",
                    mode = "Solo",
                    map = "Iron Cage",
                    entryFeeCoins = 15,
                    prizePoolCoins = 200,
                    perKillCoins = 4,
                    matchPoints = 40,
                    matchTime = "Today, 07:45 PM",
                    totalSlots = 16,
                    filledSlots = 11,
                    status = "UPCOMING",
                    roomId = "WOLF778",
                    roomPassword = "112",
                    rules = "1. Best of 5 rounds.\n2. Desert Eagle / Shotgun allowed.\n3. No character skill abuse.\n4. Winner takes 200 Coins + Per kill bonus."
                ),

                // 4. Free Fire Lone Wolf - 2v2 Duo
                Tournament(
                    id = "ff_lonewolf_duo_02",
                    title = "Free Fire Lone Wolf Duo Masters",
                    game = "Free Fire",
                    category = "LONE_WOLF",
                    mode = "1v1",
                    map = "Iron Cage",
                    entryFeeCoins = 25,
                    prizePoolCoins = 320,
                    perKillCoins = 5,
                    matchPoints = 50,
                    matchTime = "Tomorrow, 06:00 PM",
                    totalSlots = 12,
                    filledSlots = 5,
                    status = "UPCOMING",
                    roomId = "DUOWOLF",
                    roomPassword = "334",
                    rules = "1. Standard Lone Wolf Duo rules.\n2. Fair play guaranteed. Recording advised."
                ),

                // 6. Free Fire Battle Royale - Squad
                Tournament(
                    id = "ff_br_squad_01",
                    title = "Free Fire Bermuda Battle Royale",
                    game = "Free Fire",
                    category = "CLASSIC",
                    mode = "Squad",
                    map = "Bermuda",
                    entryFeeCoins = 25,
                    prizePoolCoins = 500,
                    perKillCoins = 6,
                    matchPoints = 80,
                    matchTime = "Tomorrow, 07:00 PM",
                    totalSlots = 12,
                    filledSlots = 7,
                    status = "UPCOMING",
                    roomId = "BERM889",
                    roomPassword = "901",
                    rules = "1. Classic Bermuda map squad tournament.\n2. Booyah reward: 500 coins."
                ),

                // 7. Free Fire Clash Squad 4v4 Champions Cup
                Tournament(
                    id = "ff_cs_squad_01",
                    title = "Free Fire Clash Squad 4v4 Champions Cup",
                    game = "Free Fire",
                    category = "CLASH_SQUAD",
                    mode = "Squad",
                    map = "Bermuda CS (Clock Tower)",
                    entryFeeCoins = 35,
                    prizePoolCoins = 600,
                    perKillCoins = 6,
                    matchPoints = 80,
                    matchTime = "Today, 09:15 PM",
                    totalSlots = 8,
                    filledSlots = 4,
                    status = "UPCOMING",
                    roomId = "CS7744",
                    roomPassword = "442",
                    rules = "1. Official 4v4 Clash Squad rules (7 Rounds to win).\n2. Grenades limit 2 per round. Gun properties OFF.\n3. Squad of 4 Players + 1 optional Substitute.\n4. Screenshot mandatory for win & kill verification."
                )
            )
            dao.insertTournaments(tournaments)

            // Seed Free Fire Match Results
            val sampleRankingsLoneWolf = """
                [
                    {"rank": 1, "playerName": "ViperSniper", "inGameId": "776655443", "kills": 5, "killPoints": 20, "matchPoints": 40, "coinsWon": 150},
                    {"rank": 2, "playerName": "CyberStriker", "inGameId": "887766554", "kills": 3, "killPoints": 12, "matchPoints": 15, "coinsWon": 50}
                ]
            """.trimIndent()

            dao.insertMatchResult(
                MatchResult(
                    id = "result_wolf_01",
                    tournamentId = "ff_wolf_past_01",
                    tournamentTitle = "Free Fire Lone Wolf Duel #1",
                    game = "Free Fire",
                    category = "LONE_WOLF",
                    mode = "Solo",
                    matchDate = "Yesterday, 07:30 PM",
                    winnerName = "ViperSniper",
                    totalKills = 8,
                    rankingsJson = sampleRankingsLoneWolf
                )
            )

            val sampleRankingsClashSquad = """
                [
                    {"rank": 1, "playerName": "ViperKillers CS Team", "inGameId": "776655443", "kills": 24, "killPoints": 120, "matchPoints": 80, "coinsWon": 350},
                    {"rank": 2, "playerName": "CyberStriker CS Squad", "inGameId": "887766554", "kills": 20, "killPoints": 100, "matchPoints": 40, "coinsWon": 150}
                ]
            """.trimIndent()

            dao.insertMatchResult(
                MatchResult(
                    id = "result_cs_01",
                    tournamentId = "ff_cs_past_01",
                    tournamentTitle = "Free Fire Clash Squad Blitz #1",
                    game = "Free Fire",
                    category = "CLASH_SQUAD",
                    mode = "Squad",
                    matchDate = "Yesterday, 08:00 PM",
                    winnerName = "ViperKillers CS Team",
                    totalKills = 44,
                    rankingsJson = sampleRankingsClashSquad
                )
            )

            // Seed Coin Transactions
            dao.insertTransaction(
                CoinTransaction(
                    id = "tx_welcome",
                    userId = demoPlayerUid,
                    type = "SIGNUP_BONUS",
                    amount = 100,
                    description = "Welcome Bonus Coins for joining GAMING ADDA!"
                )
            )
            dao.insertTransaction(
                CoinTransaction(
                    id = "tx_daily",
                    userId = demoPlayerUid,
                    type = "DAILY_REWARD",
                    amount = 50,
                    description = "Daily Login Streak Bonus"
                )
            )
            // Seed Announcements
            dao.insertAnnouncement(
                Announcement(
                    id = "ann_free_fire_update",
                    title = "⚡ Free Fire Lone Wolf Modes Added!",
                    message = "Free Fire Lone Wolf tournaments are available now. Check the tournament rules before joining!",
                    type = "UPDATE"
                )
            )
            dao.insertAnnouncement(
                Announcement(
                    id = "ann_rules",
                    title = "🛡️ Fair Play & Anti-Hack Enforcement",
                    message = "All tournaments are strictly monitored. Players using hacks or third-party config files will be permanently banned and their virtual coins seized.",
                    type = "ALERT"
                )
            )
        }
    }
}
