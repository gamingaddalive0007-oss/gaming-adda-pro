package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Tournament
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("GAMING ADDA", appName)
  }

  @Test
  fun `verify Free Fire tournament creation`() {
    val t = Tournament(
      id = "ff_test",
      title = "Free Fire Clash Squad",
      game = "Free Fire",
      category = "CLASH_SQUAD",
      mode = "Squad",
      entryFeeCoins = 30,
      prizePoolCoins = 400,
      perKillCoins = 5,
      matchPoints = 60
    )
    assertEquals("Free Fire", t.game)
    assertEquals("CLASH_SQUAD", t.category)
    assertEquals("Squad", t.mode)
    assertEquals(5, t.perKillCoins)
    assertEquals(60, t.matchPoints)
  }
}
