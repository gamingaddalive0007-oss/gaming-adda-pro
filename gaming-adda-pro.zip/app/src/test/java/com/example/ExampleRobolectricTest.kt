package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Tournament
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("GAMING ADDA", appName)
  }

  @Test
  fun `verify BGMI TDM tournament creation`() {
    val t = Tournament(
      id = "tdm_test",
      title = "BGMI TDM Cyber Clash",
      game = "BGMI",
      category = "TDM",
      mode = "Squad",
      entryFeeCoins = 30,
      prizePoolCoins = 400,
      perKillCoins = 5,
      matchPoints = 60
    )
    assertEquals("BGMI", t.game)
    assertEquals("TDM", t.category)
    assertEquals("Squad", t.mode)
    assertEquals(5, t.perKillCoins)
    assertEquals(60, t.matchPoints)
  }
}
